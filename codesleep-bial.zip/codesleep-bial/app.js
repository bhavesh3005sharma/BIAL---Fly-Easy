require('dotenv').config();

const express = require('express');
const app = express();
const mongoose = require('mongoose');

const airportRoutes = require('./api/routes/airport');
const flightRoutes = require('./api/routes/flight');
const ticketRoutes = require('./api/routes/ticket');
const userRoutes = require('./api/routes/user');
const shopRoutes = require('./api/routes/shop');


mongoose.connect(
    "mongodb://"+process.env.COSMOSDB_HOST+":"+process.env.COSMOSDB_PORT+"/"+process.env.COSMOSDB_DBNAME+"?ssl=true&replicaSet=globaldb", {
    auth: {
        username: process.env.COSMOSDB_USER,
        password: process.env.COSMOSDB_PASSWORD
    },
    useNewUrlParser: true,
    useUnifiedTopology: true,
    retryWrites: false}
    ).then(
        () => console.log('Connection to CosmosDB successful')
    ).catch(
        (err) => console.error(err)
    );

app.use(express.json());

app.use((req, res, next)=>{
    res.header('Access-Control-Allow-Origin', '*');
    res.header(
        'Access-Control-Allow-Origin',
        'Origin, X-Requested-With, Content-Type, Accept, Authorization'
    );
    if(req.method==='OPTIONS'){
        res.header(
            'Access-Control-Allow-Methods',
            'PUT, POST, PATCH, DELETE, GET'  
        );

        return res.status(200).json({});
    }
    next();
});

app.use('/airport', airportRoutes);
app.use('/flight', flightRoutes);
app.use('/ticket', ticketRoutes);
app.use('/user', userRoutes);
app.use('/shop', shopRoutes);

app.get('*', (req, res) => res.status(404).end());

const server = app.listen(process.env.PORT, () => {
    console.log(`Listening on ${process.env.PORT}`);
});