const express = require('express');
const router = express.Router();
const airportController = require('../controller/airport');
const checkAuth = require('../middleware/check-auth');

//router.post('/', airportController.create);
router.get('/', checkAuth, airportController.fetchAll);

module.exports = router;