const express = require('express');
const router = express.Router();
const ticketController = require('../controller/ticket');
const checkAuth = require('../middleware/check-auth');

router.post('/', checkAuth, ticketController.bookTicket);
router.get('/checkList', checkAuth, ticketController.getTicketCheckList);
router.patch('/checkList', checkAuth, ticketController.editTicketCheckList);
router.get('/foodItems', checkAuth, ticketController.getFoodItems);

module.exports = router;