const express = require('express');
const router = express.Router();
const checkAuth = require('../middleware/check-auth');
const userController = require('../controller/user');

router.post('/signup', userController.signup);
router.post('/login', userController.login);
//router.post('/reset/updatePassword',userController.updatePassword);
router.patch('/checkList', checkAuth, userController.updateDefaultCheckList);
router.get('/checkList', checkAuth, userController.getDefaultCheckList);
router.get('/ticketHistory', checkAuth, userController.getUserTicketHistory);
router.patch('/:userId', checkAuth, userController.updateProfile);
router.get('/', checkAuth, userController.getUserById);
router.post('/home', checkAuth, userController.home);

module.exports = router;