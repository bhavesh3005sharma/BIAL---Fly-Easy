const express = require('express');
const router = express.Router();
const shopController = require('../controller/shop');
const checkAuth = require('../middleware/check-auth');

router.get('/list', checkAuth, shopController.getShopsList);
router.get('/foodItems', checkAuth, shopController.getShopFoodItemsList);

module.exports = router;