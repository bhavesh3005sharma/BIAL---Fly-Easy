const express = require('express');
const router = express.Router();
const flightController = require('../controller/flight');
const checkAuth = require('../middleware/check-auth');

//router.post('/', flightController.create);
router.post('/search', checkAuth, flightController.search);

module.exports = router;