const constantData = {
    "flights": [
        {
            "flightNo": "9W1",
            "company": "Indigo",
            "source": "BLR",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "1A",
            "price": "5000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "VS1",
            "company": "Vistara",
            "source": "BLR",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "2A",
            "price": "4000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "AI1",
            "company": "Air India",
            "source": "BLR",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "3A",
            "price": "3000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ1",
            "company": "SpiceJet",
            "source": "BLR",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "4A",
            "price": "2000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "9W2",
            "company": "Indigo",
            "source": "BOM",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "1B",
            "price": "6000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "VS2",
            "company": "Vistara",
            "source": "BOM",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "2B",
            "price": "5000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "AI2",
            "company": "Air India",
            "source": "BOM",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "3B",
            "price": "4000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ2",
            "company": "SpiceJet",
            "source": "BOM",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "4B",
            "price": "3000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "9W3",
            "company": "Indigo",
            "source": "MAA",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "1C",
            "price": "5000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "VS3",
            "company": "Vistara",
            "source": "MAA",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "2C",
            "price": "4000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "AI3",
            "company": "Air India",
            "source": "MAA",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "3C",
            "price": "3000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ3",
            "company": "SpiceJet",
            "source": "MAA",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "4C",
            "price": "2000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "9W4",
            "company": "Indigo",
            "source": "BBI",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "1D",
            "price": "6000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "VS4",
            "company": "Vistara",
            "source": "BBI",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "2D",
            "price": "5000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "AI4",
            "company": "Air India",
            "source": "BBI",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "3D",
            "price": "4000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ4",
            "company": "SpiceJet",
            "source": "BBI",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "4D",
            "price": "3000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "9W5",
            "company": "Indigo",
            "source": "UDR",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "1E",
            "price": "5000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "VS5",
            "company": "Vistara",
            "source": "UDR",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "2E",
            "price": "4000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "AI5",
            "company": "Air India",
            "source": "UDR",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "3E",
            "price": "3000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ5",
            "company": "SpiceJet",
            "source": "UDR",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "4E",
            "price": "2000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "AI6",
            "company": "Air India",
            "source": "BLR",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "1F",
            "price": "5000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ6",
            "company": "SpiceJet",
            "source": "BLR",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "2F",
            "price": "4000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "VS6",
            "company": "Vistara",
            "source": "BLR",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "3F",
            "price": "3000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "9W6",
            "company": "Indigo",
            "source": "BLR",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "4F",
            "price": "2000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "AI7",
            "company": "Air India",
            "source": "BOM",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "1G",
            "price": "6000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ7",
            "company": "SpiceJet",
            "source": "BOM",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "2G",
            "price": "5000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "VS7",
            "company": "Vistara",
            "source": "BOM",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "3G",
            "price": "4000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "9W7",
            "company": "Indigo",
            "source": "BOM",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "4G",
            "price": "3000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "AI8",
            "company": "Air India",
            "source": "MAA",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "1H",
            "price": "5000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ8",
            "company": "SpiceJet",
            "source": "MAA",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "2H",
            "price": "4000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "VS8",
            "company": "Vistara",
            "source": "MAA",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "3H",
            "price": "3000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "9W8",
            "company": "Indigo",
            "source": "MAA",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "4H",
            "price": "2000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "AI9",
            "company": "Air India",
            "source": "BBI",
            "destination": "UDR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "1I",
            "price": "6000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ9",
            "company": "SpiceJet",
            "source": "BBI",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "2I",
            "price": "5000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "VS9",
            "company": "Vistara",
            "source": "BBI",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "3I",
            "price": "4000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "9W9",
            "company": "Indigo",
            "source": "BBI",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "4I",
            "price": "3000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        },
        {
            "flightNo": "AI10",
            "company": "Air India",
            "source": "UDR",
            "destination": "BLR",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "4",
            "gateNumber": "1J",
            "price": "5000",
            "logo": "https://1000logos.net/wp-content/uploads/2020/09/Air-India-logo.png"
        },
        {
            "flightNo": "SJ10",
            "company": "SpiceJet",
            "source": "UDR",
            "destination": "BOM",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "3",
            "gateNumber": "2J",
            "price": "4000",
            "logo": "https://1000logos.net/wp-content/uploads/2021/07/SpiceJet-Logo.png"
        },
        {
            "flightNo": "VS10",
            "company": "Vistara",
            "source": "UDR",
            "destination": "MAA",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "2",
            "gateNumber": "3J",
            "price": "3000",
            "logo": "https://media.united.com/images/Media%20Database/SDL/MileagePlus/airline-partners/logo_partner_VISTARA_272x272-br.png"
        },
        {
            "flightNo": "9W10",
            "company": "Indigo",
            "source": "UDR",
            "destination": "BBI",
            "departureTime": "2021-12-29T04:48:09+0000",
            "arrivalTime": "2021-12-29T05:48:09+0000",
            "boardingTime": "2021-12-29T04:18:09+0000",
            "status": "Scheduled",
            "beltNumber": "1",
            "gateNumber": "4J",
            "price": "2000",
            "logo": "https://www.goindigo.in/content/dam/indigov2/6e-website/thmbnail.jpg"
        }
    ],
    "foodItems": [
        {
            "name": "Veg Sandwich",
            "quantity": "0"
        },
        {
            "name": "Chicken Sandwich",
            "quantity": "0"
        },
        {
            "name": "Coffee",
            "quantity": "0"
        },
        {
            "name": "Tea",
            "quantity": "0"
        },
        {
            "name": "Cookies (Pack of 3)",
            "quantity": "0"
        },
        {
            "name": "Noodles",
            "quantity": "0"
        },
        {
            "name": "Upma",
            "quantity": "0"
        }
    ],
    "checkList": [
        {
            "content": "Boarding Pass",
            "isChecked": false
        },
        {
            "content": "ID Proof",
            "isChecked": false
        },
        {
            "content": "Vaccination Certificate",
            "isChecked": false
        }
    ],
    "shops": [
        {
            "type": "AIRPORT_SHOP",
            "name": "Accessorize",
            "address": "BLR Airport, Bangalore",
            "description": "Ultimate stop for all New women's fashions accessories have landed! Our Accessorize bags, purses, jewellery, shoes, accessories, gifts and beachwear will get you …at BLR Aiprort",
            "rating": "3"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "ArtPort",
            "address": "BLR Airport, Bangalore",
            "description": "ArtPort by IRHPL  (Art & Artifacts) store is a fusion of contemporary-classic finishes with traditional patterns, which represents India's Art and Artifacts from Indian regions with rich heritage. Art, Artifacts &  Souvenir for yourself, your friends and family from all parts of India starting from Kashmiri's Pashmina Shawls to Palm Leaf painting of Kanyakumari are all available under one roof.",
            "rating": "4"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "Brics & Piquadro",
            "address": "BLR Airport, Bangalore",
            "description": "Brics : Founded in 1952 by Mario Briccola, in Italy. Hand-crafts business and travel leather bags and luggages. Celebrates its 65 years of timeless existence in 2017. Piquadro : Founded in 1987, in Vergato, Italy by Marco Palmieri. Italian leather goods company specializing in business and travel items in Italy and internationally. First Piquadro single branded store was opened in Milan in 2000 and it was followed by Rome two year later.Products range from men's and women's professional bags to luggage and small leather items.",
            "rating": "4"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "Forest Essentials",
            "address": "BLR Airport, Bangalore",
            "description": "It's an Indian cosmetics, skin care and perfume company that specialises in Ayurvedic preparations for its products. It was founded in 2000 by Mira Kulkarni in New Delhi, India.",
            "rating": "3"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "Arcelia",
            "address": "BLR Airport, Bangalore",
            "description": "A great fragrance is much more than just the fragrance. It’s the thought, the story and the approach behind its creation that makes it memorable. We truly believe that a great fragrance starts with its aroma and ends with myriad of memories and experiences enabling a story to be born.",
            "rating": "3"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "FabIndia",
            "address": "BLR Airport, Bangalore",
            "description": "Fabindia is India's largest private platform for products that are made from traditional techniques, skills and hand-based processes.Fabindia links over 55,000 craft based rural producers to modern urban markets, thereby creating a base for skilled, sustainable rural employment, and preserving India's traditional handicrafts in the process.Fabindia's products are natural, craft based, contemporary, and affordable.",
            "rating": "4"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "CocoCart",
            "address": "BLR Airport, Bangalore",
            "description": "Welcome to CocoCart—your prayers answered and your penance rewarded. A immense collectiono of imported chocolates for every type of person out there, cococart is the gatekeeper to a world of delicious,decadent chocolates.",
            "rating": "4"
        },
        {
            "type": "AIRPORT_SHOP",
            "name": "Buzz",
            "address": "BLR Airport, Bangalore",
            "description": "Leading Indian retail group Shopper’s Stop has opened a freshly renovated fashion-led outlet Buzz, at Kempegowda International Airport Bengaluru.Passengers travelling through have the flexibility to shop from a designer wear .The store features a range of premium national and international brands, like Ritu Kumar",
            "rating": "3"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "KFC",
            "address": "BLR Airport, Bangalore",
            "description": "Dig into the delicious, freshly made chicken dishes made with unique, signature recipes and innovative flavors at the world’s most popular chicken restaurant chain, KFC! With enough variety to please any palate and crowd favorites like Crispy Strips, Popcorn Chicken, Hot & Crispy Chicken, Rizos, Zingers, Burgers, Hot Wings, KFC is truly a treat for the travellers of Kempegowda International Airport Bengaluru.",
            "rating": "3"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Noodle",
            "address": "BLR Airport, Bangalore",
            "description": "Noodle serves delicious dishes from the various regions in Asia - featuring a variety of appetizers, dim sums, soups, noodles and rice bowls.",
            "rating": "4"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Café Coffee Day",
            "address": "BLR Airport, Bangalore",
            "description": "Café Coffee Day, a part of Coffee Day Global Limited, is India’s favourite hangout for coffee and conversation. Popularly known as CCD, we strive to provide the best experience to our guests. Our coffees are sourced from thousands of small coffee planters, who made us who we are today and we're glad to be a part of their lives. The pioneer of the coffee shop culture in India provides the perfect place to hang out and have a ton of fun over a coffee. Classic coffees such as Cappuccino and Americano are like gastronomic fuel for national as well as international travellers.",
            "rating": "4"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Puro Gusto",
            "address": "BLR Airport, Bangalore",
            "description": "Puro Gusto is a modern concept in the middle of a Coffee Shop and chic snack offer takeaway. Puro Gusto brings together local and international food habits with the typical Italian way of life; “Barista’s” serving the best beverages, great dishes and combining the latest food and beverage trends. Puro Gusto breaks away from the traditional Italian coffee bars with a new and upgraded sensorial and food experience. Combining three main pillars; the best coffee selection, fresh bakery items and a fine casual food offer.",
            "rating": "3"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Krispy Kreme",
            "address": "BLR Airport, Bangalore",
            "description": "Krispy Kreme began almost 80 years ago in Winston-Salem, NC Founder, Vernon Rudolph, bought a yeast-raised doughnut recipe from a Chef in New Orleans and even today Krispy Stores use the same Proprietary Recipe that was Used 80 years ago! Krispy Kreme Signature Product is our Original Glazed and world famous “Hot Now” Sign signals to consumers that Krispy Kreme is making fresh doughnuts. Krispy Kreme today has more than 1000 Stores in 21 Countries",
            "rating": "3"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Taste of India",
            "address": "BLR Airport, Bangalore",
            "description": "Make way for the flavorful Taste of India. Known for its quick service, the outlet is your fastest way to travel throughout India! Relish the best of Indian and fast food on the go.  Also famous for their breakfasts, one can crash here on a lazy morning to have an appetizing breakfast!",
            "rating": "4"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Chai Point",
            "address": "BLR Airport, Bangalore",
            "description": "India’s largest tea retail chain brings you a perfectly brewed cup of chai made with fresh and natural ingredients. With over 10 variants of hot chai, iced-chai and shakes, their bite-sized chai snacks make for perfect accompaniments for Indian Tea. Chai Point sells over 300,000 cups of tea a day!",
            "rating": "4"
        },
        {
            "type": "FOOD_ITEMS_SHOP",
            "name": "Tiffin Express",
            "address": "BLR Airport, Bangalore",
            "description": "Dig into piping hot Vadas, Podi Idli, Bhajji, Degree Coffee, Meter Chai and more authentic South Indian delights, paired with thundering fast service at Tiffin Express. Tuck into a delicious meal at an affordable price, when the pangs of hunger strike.",
            "rating": "3"
        }
    ],
    "shopFoodList": [
        {
            "image": "https://4.imimg.com/data4/EW/PO/MY-10347843/chicken-burger-patty-500x500.jpg",
            "name": "Chicken Burger",
            "price": "240"
        },
        {
            "image": "https://www.vegrecipesofindia.com/wp-content/uploads/2020/12/burger-recipe-4.jpg",
            "name": "Veg Burger",
            "price": "220"
        },
        {
            "image": "https://upload.wikimedia.org/wikipedia/commons/6/64/Chicken_Nuggets.jpg",
            "name": "Chicken Nuggets",
            "price": "200"
        },
        {
            "image": "https://asmallbite.com/wp-content/uploads/2018/06/Veg-Cutlet.png",
            "name": "Veg Cutlet",
            "price": "200"
        },
        {
            "image": "https://www.spendwithpennies.com/wp-content/uploads/2020/01/Crispy-Chicken-Cutlets-1-SpendWithPennies.jpg",
            "name": "Chicken Cutlet",
            "price": "250"
        },
        {
            "image": "https://blog.warriorcoffee.com/hubfs/_MG_3386.jpg",
            "name": "Coffee",
            "price": "70"
        },
        {
            "image": "https://cdn2.foodviva.com/static-content/food-images/tea-recipes/milk-tea-recipe/milk-tea-recipe.jpg",
            "name": "Tea",
            "price": "60"
        }
    ],
    "shopImages":[
        "https://media-cdn.tripadvisor.com/media/photo-s/18/a6/f6/22/photo1jpg.jpg",
        "https://media-cdn.tripadvisor.com/media/photo-s/1a/18/3a/cb/restaurant-le-47.jpg",
        "https://d4t7t8y8xqo0t.cloudfront.net/app/eazymedia/restaurant%2F110025%2Frestaurant020160519143002.jpg",
        "https://i.pinimg.com/originals/20/4b/bf/204bbfc2dcc8cae7f11d19de44700bb6.jpg"
    ],
    "flightStatuses": [
        "Scheduled",
        "Baggage Drop",
        "Security Check",
        "Boarding",
        "Departed",
        "Landed",
        "Delayed"
    ]
};

module.exports = constantData;