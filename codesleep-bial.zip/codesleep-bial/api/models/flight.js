const mongoose = require('mongoose');
const flightSchema = require('./flight-schema');

module.exports = mongoose.model('Flight', flightSchema);