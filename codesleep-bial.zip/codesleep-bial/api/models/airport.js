const mongoose = require('mongoose');

const airportSchema = mongoose.Schema({
    code : {
        type: String,
        unique: true,
        required : true
    },
    name : {
        type: String,
        required : true
    },
    wifi: {
        type:String,
        required:true,
    },
    guidelines: [String],
});

module.exports = mongoose.model('Airport', airportSchema);