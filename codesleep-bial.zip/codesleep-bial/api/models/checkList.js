const checkListSchema = {
    content: String,
    isChecked: Boolean,
};

module.exports = checkListSchema;