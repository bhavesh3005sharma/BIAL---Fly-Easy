const mongoose = require('mongoose');

const ticketFlightSchema = mongoose.Schema({
    ticket_id : {
        type: mongoose.Schema.Types.ObjectId,
        required : true
    },
    booking_user_id : {
        type: mongoose.Schema.Types.ObjectId,
        required : true
    },
    dateOfJourney: {type: Date, index: true},
});

module.exports = mongoose.model('TicketFlight', ticketFlightSchema);