const passengerSchema = {
    name: String,
    age: Number,
    gender: {
        type: String,
        enum: ['Male', 'Female'],
        required: true,
    },
    aadharNo: String,
};

module.exports = passengerSchema;