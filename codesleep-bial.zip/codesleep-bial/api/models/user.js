const mongoose = require('mongoose');
const constantData = require('../constants/constant-data');
const checkListSchema = require('./checkList');

const userSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name : {
        type: String,
        //required : true
    },
    email: {
        type:String,
        required:true,
        unique: true
    },
    password: {
        type: String,
        required:true
    },
    phone: {
        type: String,
        //required: true
    },
    age: {
        type: Number,
        //required: true
    },
    gender : {
        type: String,
        //required: true
    },
    aadharNo: {
        type: String,
        //required: true
    },
    homeCityAddress: {
        type: String,
        //required: true
    },
    profileCompleted:{
        type:Boolean,
        required: true
    },
    defaultCheckList: {
        type: [checkListSchema],
        required: true,
        default: constantData.checkList,
    }
});

module.exports = mongoose.model('User', userSchema);