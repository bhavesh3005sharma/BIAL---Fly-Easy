const mongoose = require('mongoose');
const constantData = require('../constants/constant-data');

const flightSchema = mongoose.Schema({
    flightNo : {
        type: String,
        unique: true,
        required : true
    },
    company : {
        type: String,
        required : true
    },
    source: {
        type:String,
        required:true,
    },
    destination: {
        type:String,
        required:true,
    },
    arrivalTime: {
        type:Date,
        required:true,
    },
    departureTime: {
        type:Date,
        required:true,
    },
    boardingTime: {
        type:Date,
        required:true,
    },
    status: {
        type:String,
        enum: constantData.flightStatuses,
        required:true,
    },
    beltNumber: {
        type:String,
        required:true,
    },
    gateNumber: {
        type:String,
        required:true,
    },
    price: {
        type: String,
        required: true,
    },
    logo: {
        type: String,
        required: true,
    },
});

module.exports = flightSchema;