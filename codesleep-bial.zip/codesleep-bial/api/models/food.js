const foodSchema = {
    name: String,
    quantity: Number,
};

module.exports = foodSchema;