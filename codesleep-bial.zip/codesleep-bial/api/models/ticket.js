const mongoose = require('mongoose');
const checkListSchema = require('./checkList');
const foodSchema = require('./food');
const passengerSchema = require('./passenger');

const ticketSchema = mongoose.Schema({
    booking_user_id : {
        type: mongoose.Schema.Types.ObjectId,
        required : true
    },
    flightNos: [{
        type: String,
        required:true,
    }],
    datesOfJourney: [{type: Date}],
    passengers: [passengerSchema],
    checkList: [checkListSchema],
    food_details: [[foodSchema]],
});

module.exports = mongoose.model('Ticket', ticketSchema);