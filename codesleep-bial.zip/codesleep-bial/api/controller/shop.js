const constantData = require('../constants/constant-data');
const { onError } = require('./error');

async function getShopsList(req, res){
    try {
        const requiredType = req.query.type;
        const requiredShops = constantData.shops.filter(
            item => item.type === requiredType
        );
        const result = requiredShops.map(item => { 
            return {
                ...item,
                rating: parseInt(item.rating),
                images: constantData.shopImages,
            };
        });
        return res.status(200).json({
            status: 200,
            message: "Fetched shops list successfully",
            data: result
        });
    } catch (error) {
        onError(res, error);
    }
}

async function getShopFoodItemsList(req, res){
    try {
        const result = constantData.shopFoodList.map(item => { 
            return {
                ...item,  
                price: parseInt(item.price),
            };
        });
        return res.status(200).json({
            status: 200,
            message: "Fetched shop food list successfully",
            data: result
        });
    } catch (error) {
        onError(res, error);
    }
}

module.exports.getShopsList = getShopsList;
module.exports.getShopFoodItemsList = getShopFoodItemsList;