const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const Ticket = require('../models/ticket');
const TicketFlight = require('../models/ticket-flight');
const Airport = require('../models/airport');
const {Flight} = require('../models/flight');
const strings = require('../constants/strings');
const { onError } = require('./error');
const constantData = require('../constants/constant-data');

async function bookTicket(req, res){
    try {
        const body = req.body;
        var datesOfJourney = body.datesOfJourney;
        //var recordedDatesOfJourney = [];

        const user  = await User.findOne({_id: body.userId});
        
        //Create Master Record of Ticket
        var ticket = new Ticket({
            booking_user_id: body.userId,
            flightNos: body.flightNos,
            passengers: body.passengers,
            checkList: user.defaultCheckList,
            food_details: body.foods,
            datesOfJourney: datesOfJourney,
        });

        ticket = await ticket.save();
    
        if(ticket){
            
            //Create Indexing Records of Ticket - for HomeScreen and TicketSorting

            for(let i=0; i<datesOfJourney.length; i++){
                var ticketFlight = new TicketFlight({
                    ticket_id: ticket._id,
                    dateOfJourney: datesOfJourney[i],
                    booking_user_id: body.userId,
                });
                
                ticketFlight = await ticketFlight.save();
            }

            return res.status(200).json({
                status: 200,
                message: "Ticket booked successfully!",
            });
        }else{
            throw "Unable to generate ticket";
        }
    } catch (error) {
        onError(res, error);
    }
}

async function getCheckList(req, res){
    try {
        const ticketId = req.query.ticketId;
        const ticket = await Ticket.findOne({_id: ticketId});

        if(ticket){
            return res.status(200).json({
                status: 200,
                message: "Fetched ticket checklist successfully",
                data: ticket.checkList,
            });
        }else{
            throw "Cannot find ticket";
        }
    } catch (error) {
        onError(res, error);
    }
}

async function editCheckList(req, res){
    try {
        const body = req.body;
        const ticket = await Ticket.updateOne(
            {_id: body.ticketId},
            {checkList: body.checkList}
        );

        if(ticket){
            return res.status(200).json({
                status: 200,
                message: "Checklist updated successfully",
            });
        }else{
            throw "Unable to update ticket checkList";
        }
    } catch (error) {
        onError(res, error);
    }
}

async function getFoodItems(req, res){
    try {
        const result = constantData.foodItems.map((item) => {
            return {
                ...item,
                quantity: parseInt(item.quantity),
            }
        });
        return res.status(200).json({
            status: 200,
            message: "Fetched available food items successfully.",
            data: result,
        });
    } catch (error) {
        onError(res, error);
    }
}
module.exports.bookTicket = bookTicket;
module.exports.getTicketCheckList = getCheckList;
module.exports.editTicketCheckList = editCheckList;
module.exports.getFoodItems = getFoodItems;