const strings = require('../constants/strings');

function onError(res, error){
    console.log(error);
    return res.status(200).json({
        status: 404,
        message: strings.ERROR_OCCURED,
    });
}

module.exports.onError = onError;