const mongoose = require('mongoose');
const Airport = require('../models/airport');
const { onError } = require('./error');

async function createAirport(req, res){
    try {
        const content = req.body;
        var airport = new Airport(content);
        airport = await airport.save();
    
        if(airport)
            return res.status(200).json({
                status: 200,
                message: "Airport created successfully!",
            });
        else
            throw "Unable to create airport";
    } catch (error) {
        onError(res, error);
    }
}

async function listAllAirports(req, res) {
    try {
        return res.status(200).json({
            status: 200,
            message: "Fetched all airports successfully!",
            data: await Airport.find(),
        });
    } catch (error) {
        onError(res, error);
    }
}

module.exports.create = createAirport;
module.exports.fetchAll = listAllAirports;