const User = require('../models/user');
const Ticket = require('../models/ticket');
const Airport = require('../models/airport');
const Flight = require('../models/flight');
const strings = require('../constants/strings');
const { onError } = require('./error');
const { flights } = require('../constants/constant-data');

/*
    Overwrites flights
*/
async function createFlight(req, res) {
    try{
        await Flight.deleteMany();
        flights.forEach(async element => {
            try {
                var newFlight = new Flight(element);
                newFlight = await newFlight.save();   
            } catch (error) {
                
            }
        });
        
        return res.status(200).json({
            status: 200,
            message: "Flights created successfully!",
        });
    }catch(error){
        onError(res, error);
    }
}

async function searchFlight(req, res){
    try {
        const source = req.body.source;
        const dest = req.body.destination;
        //TODO: Enter dummy data for flights.
        const date = Date.parse(req.body.date);
        const dateNow = Date.now();
        var flights = [];

        //90 Days
        if(date - dateNow < 1000*60*60*24*90){
            flights = await Flight.find({
                source: source,
                destination: dest,
            });
        }

        return res.status(200).json({
            status: 200,
            message: "Fetched flights successfully",
            data: flights,
        });
    } catch (error) {
        onError(res, error);
    }
}

module.exports.create = createFlight;
module.exports.search = searchFlight;