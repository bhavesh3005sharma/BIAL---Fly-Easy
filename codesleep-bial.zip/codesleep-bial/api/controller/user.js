const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const Ticket = require('../models/ticket');
const Airport = require('../models/airport');
const Flight = require('../models/flight');
const strings = require('../constants/strings');
const { onError } = require('./error');
const TicketFlight = require('../models/ticket-flight');

async function signup(req, res){
    try {
        const user = await User.find({email: req.body.email});
        if(user.length >= 1)
            return res.status(200).json({
                status:404,
                message: "Email already exists!",
            });
        else{
            bcrypt.hash(req.body.password, 10, (err, hash) => {
                if(err){
                    onError(res, err);
                }else{
                    const user = new User({
                        _id: mongoose.Types.ObjectId(),
                        email: req.body.email,
                        password: hash,
                        profileCompleted: false,
                    });
                    user
                        .save()
                        .then(result => {
                            res.status(200).json({
                                status:200,
                                message: 'New user was created successfully!'
                            });
                        });
                }
            });
        }
    } catch (error) {
        onError(res, error);
    }
}

async function login(req, res, next) {
    try {
        const user = await User.find({email : req.body.email});
        if(user.length < 1){
            return res.status(200).json({
                status:404,
                message : "User doesn't exist!",
            });
        }

        bcrypt.compare(req.body.password, user[0].password, async (err, result) => {
            if(err){
                return res.status(200).json({
                    status: 400,
                    message : "Wrong password!"
                });
            }
            if(result){
                const tok = jwt.sign({
                    email : user[0].email,
                    userID : user[0]._id  
                },
                process.env.JWT_SECRET_USUAL,
                {
                    expiresIn : "30d"
                });
                return res.status(200).json({
                    status:200,
                    message : "Login successful",
                    token: tok,
                    data: user[0]._doc
                });
            }
            else{
                return res.status(200).json({
                    status:401,
                    message : strings.AUTH_FAILED
                });
            }
        });
    } catch (error) {
        onError(res, error);
    }
}

async function updatePassword(req, res, next){
    User
    .find({email: req.body.email, resetRequestAccepted:true})
    .exec()
    .then(user => {
        if(user.length < 1)
            return res.status(200).json({
                status:400,
                message: strings.BAD_REQUEST
            });
        else{
            bcrypt.hash(req.body.password, 10, (err, hash) => {
                if(err){
                    return res.status(500).json({error:err});
                }
                User
                .updateOne(
                    {email:req.body.email},
                    {password:hash, resetRequestAccepted:false}
                )
                .then(result => {
                    console.log(result);
                    res.status(200).json({
                        status:200,
                        message: 'Password was updated successfully.'
                    });
                })
                
            });
        }
    })
    .catch(error => {
        onError(res, error);
    });
}

async function updateProfile(req, res, next){
    try {
        const userId = req.params.userId;

        const user = await User.updateOne(
            {_id : mongoose.Types.ObjectId(userId)},
            {$set : 
                {
                    name: req.body.name,
                    phone: req.body.phone,
                    age: req.body.age,
                    gender: req.body.gender,
                    aadharNo: req.body.aadharNo,
                    homeCityAddress: req.body.homeCityAddress,
                    profileCompleted:true
                }
            });
        if(user)
            res.status(200).json({
                status: 200,
                message: "User profile updated successfully." 
            });
        else
            throw "Some error occured in updating user profile!";
    } catch (error) {
        onError(res, error);
    }
}

async function getUserById(req, res, next) {
    try {
        const userId = req.query._id;

        const result = await User.findOne({_id : mongoose.Types.ObjectId(userId)});
        if(result){
            res.status(200).json({
                status: 200,
                message: "Profile fetched successfully.",
                data: result
            });
        }
        else{
            res.status(200).json({
                status: 404,
                message: strings.NOT_FOUND
            });
        }
    } catch (error) {
        onError(res, error);
    }
}

async function home(req, res, next) {
    try {
        const userId = req.body.userId;
        const airportCode = req.body.airport;
        const today = new Date();

        const airport = await Airport.findOne({code: airportCode});
        const departures = await Flight.find({source: airportCode});
        const arrivals = await Flight.find({destination: airportCode});

        //Fetch proper ticket-flight
        const ticketFlights = await TicketFlight.find({
                booking_user_id: mongoose.Types.ObjectId(userId),
                dateOfJourney: {$gt : today}
            }).sort({
                dateOfJourney: 1
            });
        
        var latestTicket = null;

        //If there is a pending flight to be taken
        if(ticketFlights.length > 0){
            //Find ticket via ticket_id of ticketFlight
            const ticket = await Ticket.findOne({
                _id: mongoose.Types.ObjectId(ticketFlights[0].ticket_id)
            });

            //Collect latest flight info via flightNo field of Ticket Model
            const flights = [];
            for(let i=0; i < ticket.flightNos.length; i++){
                const flightNo = ticket.flightNos[i];
                flights.push(await Flight.findOne({flightNo: flightNo}));
            }

            //Set flights field
            latestTicket = {
                ...ticket._doc, 
                flights: flights
            };
        }

        return res.status(200).json({
            status: 200,
            message: "Fetched home successfully.",
            wifi_password: airport.wifi,
            guidelines: airport.guidelines,
            arrival_flights: arrivals,
            departure_flights: departures,
            latest_ticket: latestTicket,
        });
    } catch (error) {
        onError(res, error);
    }
}

async function getDefaultCheckList(req, res){
    try {
        const userId = req.query._id;
        const user = await User.findOne({_id: userId});

        if(user){
            return res.status(200).json({
                status: 200,
                message: "Fetched user default checklist successfully",
                data: user.defaultCheckList,
            });
        }else{
            throw "Cannot find user";
        }
    } catch (error) {
        onError(res, error);
    }
}

async function updateDefaultCheckList(req, res){
    try {
        const userId = req.query._id;
        const body = req.body;
        
        const user = await User.updateOne(
            {_id: userId},
            {defaultCheckList: body.checkList},
        );

        if(user){
            return res.status(200).json({
                status: 200,
                message: "Updated user default checklist successfully.",
            });
        }else{
            throw "Cannot update user default checklist";
        }
    } catch (error) {
        onError(res, error);
    }
}

async function getTicketHistory(req, res){
    try {
        //TODO: Entire Flight Model
        const userId = req.query._id;
        const tickets = await Ticket.find({booking_user_id: userId});
        const result = [];

        for(let i=0; i<tickets.length; i++){
            var ticket = tickets[i]._doc;
            const flights = [];
            for(let j=0; j < ticket.flightNos.length; j++){
                const flightNo = ticket.flightNos[j];
                flights.push(await Flight.findOne({flightNo: flightNo}));
            }
            ticket.flights = flights;
            result.push(ticket);
        }

        return res.status(200).json({
            status: 200,
            message: "Fetched user ticket history successfully.",
            data: result,
        });
    } catch (error) {
        onError(res, error);   
    }
}

module.exports.signup = signup;
module.exports.login = login;
module.exports.updatePassword = updatePassword;
module.exports.updateProfile = updateProfile;
module.exports.getUserById = getUserById;
module.exports.home = home;
module.exports.getDefaultCheckList = getDefaultCheckList;
module.exports.updateDefaultCheckList = updateDefaultCheckList;
module.exports.getUserTicketHistory = getTicketHistory;